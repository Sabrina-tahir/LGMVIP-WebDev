from django.http.response import HttpResponse
from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request , 'home.html')

def hotel(request):
    return render(request , 'hotels.html')

def book(request):
    return render(request , 'book.html')